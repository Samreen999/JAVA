/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bingo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Benehiko
 */
public class HumanPlayer implements Player{

    private BingoCard bc;
    private int[] playerNumbers = new int[4];
    
    public HumanPlayer()
    {
        chooseNumbers();
        bc = new BingoCard(playerNumbers[0], playerNumbers[1], playerNumbers[2], playerNumbers[3]);
    }
    
    @Override
    public void checkForNumber(int testNumber) {
          bc.markOff(testNumber);
    }

    @Override
    public void chooseNumbers() {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        for (int i=0; i<=3; i++)
        {
            int number = i+1;
         System.out.println("Enter the "+number+ " number for the player");
            try {
                playerNumbers[i] = Integer.parseInt(br.readLine());
            } catch (IOException ex) {
                System.out.println("Error happened: "+ ex);
            }
        }
    }

    @Override
    public void printRemaining() {
        System.out.println(bc.getRemaining());
    }

    @Override
    public boolean checkIfWon() {
        if (bc.areAllMarkedOff())
            return true;
        
        return false;
    }
    
}
