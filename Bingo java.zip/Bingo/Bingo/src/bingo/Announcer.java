/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bingo;

import java.util.ArrayList;

/**
 *
 * @author Benehiko
 */
public abstract class Announcer{
    
    protected ArrayList<Player> arrPlayers = new ArrayList<>();
    
    public abstract void chooseNextNumber();
    
    public void addNewPlayer(Player player)
    {
        arrPlayers.add(player);
    }
    
    public void announceNextNumber(int announcedNum)
    {
        for (Player player : arrPlayers)
        {
            player.checkForNumber(announcedNum);
        }
    }
}
