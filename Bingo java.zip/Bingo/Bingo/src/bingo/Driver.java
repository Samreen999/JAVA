/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bingo;

import java.util.Scanner;

/**
 *
 * @author Benehiko
 */
public class Driver {

    private Announcer theAnnouncer; // Announcer to be used for current round

    private Player[] players; // Initially 2 players to be used for each round.

    private Scanner scan;
    private boolean playAgain; 
 
    public Driver()
    {
     scan = new Scanner(System.in);   
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        Driver mainProgram = new Driver();
        mainProgram.start();
    }
    
    public void start()         
    {
       int curRound = 0;
         char response;

         playAgain = true;

         while (playAgain)
         {
         curRound++;
         System.out.println("Round "+curRound);

         newRound(); // Set up participants for the current round.
         System.out.println("Round Begins...");
         playRound();

         System.out.println("Play another round? (Y/N)");
         response = scan.nextLine().toUpperCase().charAt(0);

         if (response != 'Y')
         playAgain = false;
         } 

    }
    
    private void newRound()
    {
            System.out.println("Which type of Announcer do you want?");
            System.out.println("1. the Random Announcer");
            System.out.println("2. the Manually-Controlled Announcer");
            players = new Player[2];
            int response = getUserSelection(1,2);
            if (response == 1)
            {
              players[0] = new RandomPlayer();
              players[1] = new RandomPlayer();
              theAnnouncer = new RandomAnnouncer(players);
             
            
            }else
            {
             players[0] = new HumanPlayer();
             players[1] = new HumanPlayer();
             theAnnouncer = new ManualAnnouncer(players);
             
            }
            
    }
    
    private void playRound()
    {
        boolean gameOver = false;
         int i;
         int totalNumbers = 0; 

         while (!(gameOver || totalNumbers >= 25)) // Limit 25 announcements per game.
         {
             
         theAnnouncer.chooseNextNumber();   
         
         // show status
         for (i = 0; i < theAnnouncer.arrPlayers.size(); i++)
         {
         System.out.print("Player " + (i+1) + ":\tNumbers Remaining: ");
         theAnnouncer.arrPlayers.get(i).printRemaining();
         }
         
         
         i = 0;
         for (Player player: theAnnouncer.arrPlayers)
         {
          i++;
          if (player.checkIfWon())
           {
              System.out.println("Player "+i+" has won");
              gameOver = true;
           }
         }

         totalNumbers++; // To prevent an infinite loop.
         } 

    }
    
        // Utility Methods that are used throughout FIT2034


     // METHOD: getUserSelection
     // PURPOSE: To obtain from the user a selection (an integer) from a range of values
     // PASSED:
     // lower - the Lowest permissible value the user can enter as their selection.
     // upper - the Highest permissible value the user can enter
     // RETURNS:
     // The value entered by the user, unless the "lower" parameter was higher
     // than the "upper" parameter, in which case 0 is returned.
     // EFFECTS:
     // A prompt is displayed on the screen to ask the user for a value in the range.
     // Input is sought from the user via the keyboard (System.in)
     public int getUserSelection(int lower, int upper)
     {
         int userInput;

         if (lower > upper)
         return 0;

         do {
         System.out.print("Enter a selection ("+lower + "-" + upper+"):");
         userInput = scan.nextInt(); // obtain the input
         scan.nextLine(); // gets rid of the newline after the number we
         // just read

         if (userInput < lower || userInput > upper)
         System.out.println("Invalid choice.");
         } while (userInput < lower || userInput > upper);
         System.out.println(); // put a space before the next output

         return userInput;
     } 
}
