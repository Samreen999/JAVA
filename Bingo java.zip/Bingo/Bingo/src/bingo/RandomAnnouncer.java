/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bingo;

/**
 *
 * @author Benehiko
 */
public class RandomAnnouncer extends Announcer{
    
    public RandomAnnouncer(Player[] player)
    {
        addNewPlayer(player[0]);
        addNewPlayer(player[1]);
        
    }
    
    @Override
    public void chooseNextNumber() {
       int value = (int)(Math.random()*90)+10;
       System.out.println("Anouncer announces the value: "+value);
       announceNextNumber(value);
    }

 
    
}
