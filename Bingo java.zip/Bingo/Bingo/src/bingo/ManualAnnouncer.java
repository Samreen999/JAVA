/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bingo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Benehiko
 */
public class ManualAnnouncer extends Announcer{

    
    public ManualAnnouncer(Player[] player)
    {
        addNewPlayer(player[0]);
        addNewPlayer(player[1]);
    }
    
    @Override
    public void chooseNextNumber() {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter the number to announce");
        int value =0;
        try {
            value = Integer.parseInt(br.readLine());
        } catch (IOException ex) {
           System.out.println("Error happened :"+ex);
        }
        
        System.out.println("The announcer announces the value:" +value);
        announceNextNumber(value);
        
    }
    
}
