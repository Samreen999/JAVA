/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bingo;

/**
 *
 * @author Benehiko
 */
public class RandomPlayer implements Player{
      
    private int[] playerNum = new int[4];
    private BingoCard bc;
    
    
    public RandomPlayer()
    {
     chooseNumbers();
     bc = new BingoCard(playerNum[0],playerNum[1],playerNum[2],playerNum[3]);
     
    }
    
    @Override
    public void checkForNumber(int testNumber) {
        bc.markOff(testNumber);
    }

    @Override
    public void chooseNumbers() {
        int[] value = new int[4];
        for (int i=0; i<= 3; i++){
            value[i] = (int)(Math.random()*90)+10;
        }
        
        this.playerNum = value;
    }

    @Override
    public void printRemaining() {
       //BingoCard class 
       System.out.println(bc.getRemaining());
    }

    @Override
    public boolean checkIfWon() {
       if (bc.areAllMarkedOff())
           return true;
       
       return false;
    }
    
}
