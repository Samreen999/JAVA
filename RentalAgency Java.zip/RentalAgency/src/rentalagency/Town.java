package rentalagency;

public class Town
{
    private String name;
    private String postal;
    
    public Town()
    {
        this.name = "";
        this.postal = "";
    }
    
    public Town(String name, String postal)
    {
        this.name = name;
        this.postal = postal;
        
    }
    
    public String getName()
    {
        return this.name;
    }
    
    public String getPostal()
    {
        return this.postal;
    }
    
    @Override
    public String toString()
    {
        return "Town name: "+getName()+" ("+getPostal()+")";
    }
    
}