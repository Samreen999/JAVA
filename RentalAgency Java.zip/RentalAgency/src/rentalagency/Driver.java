package rentalagency;
import java.util.Scanner;
import java.util.ArrayList;

/*

Global Variables
  Private:
    arrHouse
        -Type: ArrayList of type House

    arrTowns
        -Type: ArrayList of type Town
      
    arrOwners
        -Type: ArrayList of type Person

    arrTenants
        -Type: ArrayList of type Person

 Public:
    None;


Method description.

    private void clearConsole();
        -This method clears the console

    private void menu();
        -This method is the core of the program. It displays the menu options
        to the user as well as does the interacting between other methods.

    private boolean addTenants(int i);
        -This method adds a tenant to the selected house (int i) and returns 
        true if it was successful and false if it failed;

    private Town townMenu();
        -This method provides the user of a set of options for selecting
        a town as well as creating a new town.

    private String[] landlordMenu();
        -This method returns the name and number of the landlord selected or 
        made by the user in the form of a string array with size 2.

    private int leaseMenu()
        -This gives the user a menu of all the known properties.
        It returns the index of the property that has been selected.

    private String setUserOptions(String)
        -This methods accepts a string and then displays it in the console
        and awaits for user input. Once the user has input something it returns
        it.

    private String[] tenantMenu()
        -Provides a menu to select already known tenants and a way to add new.
        It returns the name and number of the tenant as a String array with
        size 2.

    private void createHouse(Town town,String address)
        -Accepts a town and address which is then used to call the constructor
        of the House class.
        It prints out the details of the house after its creation and 
        returns nothing.
    
    private int leasedHouses()
        -Prints out a menu of all the leased properties. It also allows the
        user to select a property. It returns the index of the property in the
        house array.

    private String[] getValues(String temp)
        -Accepts a string with the delimiter "," and returns a string array of 
        size depending on the amount of delimiters.

    private void switches(int menu)
        -Accepts the menu wanting to be used. It then displays the menu
        selected.
        
        
*/



public class Driver
{
    private static final ArrayList<House> arrHouse = new ArrayList<>();
    private static final ArrayList<Town> arrTowns = new ArrayList<>();
    private static final ArrayList<Person> arrOwners = new ArrayList<>();
    private static final ArrayList<Person> arrTenants = new ArrayList<>();
        
    public static void main(String[] args)
    {
        arrTowns.add(new Town("LittleField","1023"));
        arrTowns.add(new Town("WaterfallValley","3021"));
        arrTowns.add(new Town("Pinewell","1032"));
        arrOwners.add(new Person("Bob","12345678"));
        arrOwners.add(new Person("Shelly","98765432"));
        arrHouse.add(new House("123 Langly", arrTowns.get(0),arrOwners.get(0)));
        arrHouse.add(new House("3rd Avenue",arrTowns.get(1),arrOwners.get(0)));
        arrHouse.add(new House("31 Ceril",arrTowns.get(2),new Person()));
        new Driver().menu();
        
    }
    
    private void clearConsole()
    {
        final String os = "\033[";
        System.out.print(os + "2J");
    }
    private void menu()
    {
        
        clearConsole();
        System.out.println("|=========== Rental Program ============|\n|\t\t\t\t\t|");
        switches(1);
    }
    
    private boolean addTenants(int i)
    {
       
      String input = setUserOptions("\nEnter the new Tenant in the format (Name,Number)");
      try{
      String[] arrTemp = getValues(input);
      arrTenants.add(new Person(arrTemp[0],arrTemp[1]));
      int tenantSize = arrTenants.size()-1;
      return arrHouse.get(i).addTenant(arrTenants.get(tenantSize));
      }catch(Exception e)
      {
          System.out.println("Woops you entered something wront. Lets try that again.");
          addTenants(i);
      }
      return false;
    }
    private Town townMenu()
    {
        clearConsole();
        System.out.println("Towns to choose from:\n");
        int counter =0;
        Town townDetails = new Town();
        
        for (Town i : arrTowns)
        {
            
            System.out.println(counter+"."+i.getName());
            counter++;
        }
        String towns = setUserOptions("\nEnter -1 for a custom Town entry.\nEnter -2 to go to the main menu.\nEnter -3 to Exit the program");
        
        switch (towns)
        {
            case "-1" :
                boolean active = true;
                while (active)
                {
                String townsDetails = setUserOptions("\nEnter the new Town details in the format (Name, Postal code)");
                
                try{
                String[] arrTown = getValues(townsDetails);
                townDetails = new Town(arrTown[0],arrTown[1]);
                arrTowns.add(townDetails);
                active = false;
                }catch(Exception e)
                 {
                     System.out.println("Woops you entered something wrong! Lets try that again.");
                 }
                }
                break;
            case "-2" :
                menu();
                break;
            case "-3" :
                System.exit(0);
                break;
            default:
                for (int i=0; i<= arrTowns.size()-1; i++)
                {
                    if (Integer.parseInt(towns) == i)
                    {
                    townDetails = arrTowns.get(i);
                    break;
                    }
                }
                break;
        }      
        System.out.println("Town chosen ("+townDetails.getName()+") with postal code:"+townDetails.getPostal());
        return townDetails;
    }
    private String[] landlordsMenu()
    {
        clearConsole();
        String ownerName = "";
        String ownerNumber = "";
        System.out.println("Landlords to choose from:\n");
        if (arrOwners.isEmpty())
        {System.out.println("No landlords to choose from.");}
        else{
        for (int i=0; i<= arrOwners.size()-1;i++)
        {
            System.out.println(i+"."+arrOwners.get(i).getName()+"\t");
        }
        }
        String landlords = setUserOptions("\nEnter -1 for a custom landlord entry.\nEnter -2 for Main menu.\nEnter 'Exit' to end the program.");
        
        switch (landlords)
        {
            case "-1" : 
                boolean active = true;
                
                while (active)
                {
                    String landlordsDetails = setUserOptions("Enter Landlord name and phone number seperated by a comma eg. (Name, Number)");
                    try {
                    String[] arrLandLordNew = getValues(landlordsDetails);
                    arrOwners.add(new Person(arrLandLordNew[0],arrLandLordNew[1]));
                    ownerName = arrLandLordNew[0];
                    ownerNumber = arrLandLordNew[1];
                    active = false;
                    }catch(Exception e)
                    {
                        System.out.println("Woops you entered something wrong! Lets try that again.");
                    }
                }
                break;
            case "-2" :
                menu();
                break;
            case "-3" :
                System.exit(0);
                break;
            default :
                 for (int i=0; i<= arrOwners.size()-1;i++)
                {
                   if (Integer.parseInt(landlords) == i)
                   {
                       ownerName = arrOwners.get(i).getName();
                       ownerNumber = arrOwners.get(i).getNumber();
                       break;
                   }
                }
                break;
        }
     
        System.out.println("Landlords chosen ("+ownerName+") with number : ("+ownerNumber+")");
        String[] owners = {ownerName, ownerNumber};
        return owners;
    }
    private int leaseMenu()
    {
        clearConsole();
        int counter = 0;
        System.out.println("Current known properties:\n");
        for (int i =0; i<= arrHouse.size()-1; i++)
        {
            System.out.println(i+"."+arrHouse.get(i)+"\t");
        }
        String selection = setUserOptions("\nEnter -1 to go to the main menu.\nEnter -2 to exit the program.");
        switch (selection) {
            case "-1":
                menu();
                break;
            case "-2":
                System.exit(0);
            default:
                   if (Integer.parseInt(selection) <= arrHouse.size()-1)
                    {
                        counter = Integer.parseInt(selection);
                        break;
                    }
                break;
        }
        System.out.println("House chosen:"+arrHouse.get(counter).toString());
        return counter;
    }
    private String setUserOptions(String question)
    {
              
        String input = "";
        
        boolean active = true;
        while (active)
        {
           try
           {
            System.out.println(question);
            Scanner s = new Scanner(System.in);
            
            input = s.nextLine();
            if (input.equals(""))
            {
             active = true;
            }else
            {
             active = false;
            }
           }catch(Exception e)
           {
               System.out.println("Nothing entered. Lets try that again.");
           }
        }
        return input;
    }
    private String[] tenantMenu()
    {
        clearConsole();
        String tenantName = "";
        String tenantNumber = "";
        System.out.println("Tenants to choose from:\n");
        if (arrTenants.size() == 0)
        {System.out.println("No tenants to choose from.");}
        else{
        for (int i=0; i<= arrTenants.size()-1;i++)
        {
            System.out.println(i+"."+arrTenants.get(i).getName()+"\t");
        }
        }
        String selection = setUserOptions("\nEnter -1 for a custom tenant entry.\nEnter -2 for Main menu.\nEnter -3 to end the program.");
        
        switch (selection)
        {
            case "-1" :
                    boolean active = true;
                    
                    while (active)
                    {
                       String tenantDetails = setUserOptions("Enter tenant name and phone number seperated by a comma eg. (Name, Number)");
                     try
                     {
                        
                        String[] arrTenantsNew = getValues(tenantDetails);
                        arrTenants.add(new Person(arrTenantsNew[0],arrTenantsNew[1]));
                        tenantName = arrTenantsNew[0];
                        tenantNumber = arrTenantsNew[1];
                        active = false;
                     }catch(Exception e)
                     {
                        System.out.println("Woops you entered something wrong. Lets try that again.");
                     }
                    }
                break;
                
            case "-2" :
                menu();
                break;
                
            case "-3" :
                System.exit(0);
                break;
            default :
                for (int i=0; i<= arrTenants.size()-1;i++)
                {
                   if (Integer.parseInt(selection) == i)
                   {
                       tenantName = arrTenants.get(i).getName();
                       tenantNumber = arrTenants.get(i).getNumber();
                       break;
                   }
                }
                break;
        }  
        System.out.println("Tenant chosen ("+tenantName+") with number : ("+tenantNumber+")");
        String[] tenant = {tenantName, tenantNumber};
        return tenant;
    }
    private void createHouse(Town town,String address)
    {
        clearConsole();
        arrHouse.add(new House(address,town,arrOwners.get(arrOwners.size()-1)));
        System.out.println("New house was created.\nHouse details: "+arrHouse.get(arrHouse.size()-1).toString()+"\nOwner: "+arrOwners.get(arrOwners.size()-1).getName());
        String option = setUserOptions("Enter -1 to go back to the main menu.\nEnter -2 to Exit the program.");
        switch(option)
        {
            case "-1": menu();
            break;
            case "-2": System.exit(0);
            default :
               System.out.println("That is not an option, returning to the main menu anyway.");
               menu();
               break;
               
        }
    }
    
    private int leasedHouses()
    {
        clearConsole();
        System.out.println("Current leased properties:\n");
        int counter =0;
        for (int i =0; i<= arrHouse.size()-1; i++)
        {
            if (arrHouse.get(i).getLease().getNumWeeks()>0)
            {
            System.out.println(i+"."+arrHouse.get(i)+"\t");
            }
        }
        String selection = setUserOptions("\nEnter -1 to go to the main menu.\nEnter -2 to exit the program.");
        
        switch (selection)
        {
            
            case "-1" : menu();
            break;
            case "-2" : System.exit(0);
            break;
            default: 
                if (Integer.parseInt(selection) <= arrHouse.size()-1)
                {
                    counter = Integer.parseInt(selection);
                    break;
                }
            break;
            
        }
       
        System.out.println("House chosen:"+arrHouse.get(counter).toString());
        return counter;
    }
    
    private String[] getValues(String temp)
    {
        String[] arrValues = temp.split(",");
        return arrValues;
    }
    
    private void switches(int menu)
    {
        String input;
        
        
       switch (menu)
       {
           case 1:
               int choice = Integer.parseInt(setUserOptions("|1.Add House\t\t\t\t| "
                + "\n|2.Add Lease\t\t\t\t| "
                + "\n|3.Process Rent\t\t\t\t|"
                + "\n|4.Report on Property\t\t\t|"
                + "\n|5.Add/Remove Tenants to Lease\t\t|"
                + "\n|6.Exit Program\t\t\t\t|"
                + "\n|=======================================|"));
        
                    switch (choice)
                        {
                            case 1:
                            String[] arrTemp;
                            int iCounter;
                            int arraySize;

                            arrTemp = landlordsMenu();
                            String address = setUserOptions("Enter the address of the house.");
                            Town chosenTown = townMenu();
                            createHouse(chosenTown,address);
                            break;
                            //Case 2 is for Adding lease.
                            case 2:
                                //Retrieving the index of the current house the user selected.
                                iCounter = leaseMenu();
                                //Getting the array
                                arrTemp = tenantMenu();
                                arrTenants.add(new Person(arrTemp[0],arrTemp[1]));
                                String amount = setUserOptions("Enter the amount the tenant has to pay weekly.");
                                
                                String numWeeks = setUserOptions("Enter the amount of weeks the tenant will be renting.");
                                arrHouse.get(iCounter).establishLease(arrTenants.get(arrTenants.size()-1).getName(),arrTenants.get(arrTenants.size()-1).getNumber(),Integer.parseInt(amount),Integer.parseInt(numWeeks));
                                arraySize = arrTenants.size();
                                System.out.println("Tenant ("+arrTenants.get(arraySize-1).getName()+") added to house ("+arrHouse.get(iCounter).toString()+") with lease Amount (R "+arrHouse.get(iCounter).getLease().getRent()+ ") Number of weeks (" +arrHouse.get(iCounter).getLease().getNumWeeks()+")");
                                //Calling method switches to display menu number 2.
                                switches(2);
                
                                break;
                            case 3:
                                iCounter = leaseMenu();
                                if (arrHouse.get(iCounter).getTenant()[0].getName().equals(""))
                                {
                                    System.out.println("No tenants leased");
                                }
                                else
                                {
                                    if (arrHouse.get(iCounter).getLease().makePayment())
                                    {System.out.println("Payment made successfully for tenant ("+arrHouse.get(iCounter).getTenant()[0].getName()+") staying in house ("+arrHouse.get(iCounter).toString()+")");}
                                    else
                                    {System.out.println("Payment failed for tenant ("+arrHouse.get(iCounter).getTenant()[0].getName()+") staying in house ("+arrHouse.get(iCounter).toString()+")");}
                                }

                                
                                switches(2);
                                

                                break;
                            case 4:
                                iCounter = leaseMenu();
                                String output = "House details: "+arrHouse.get(iCounter).toString()
                                        + "\nPostal Code: "+ arrHouse.get(iCounter).getTown().getPostal()
                                        + "\nOwner details: "+arrHouse.get(iCounter).getOwner().getName() +" "+arrHouse.get(iCounter).getOwner().getNumber();
                                        if (arrHouse.get(iCounter).getLease().getNumWeeks()> 0)
                                        {
                                            output += "\nTenant(s):";
                                            int tenantAmount = -1;
                                            for (int i=0; i<= arrHouse.get(iCounter).getTenant().length-1; i++)
                                            {
                                                
                                               if (arrHouse.get(iCounter).getTenant()[i] != null)
                                               {
                                                 tenantAmount++;
                                             
                                               }
                                            }
                                            System.out.println(tenantAmount);
                                            
                                            if (tenantAmount > 0)
                                            {
                                                
                                                for (int i=0; i<= tenantAmount; i++)
                                                {
                                                    output += "\nTenant "+arrHouse.get(iCounter).getTenant()[i].toString();
                                                    
                                                }
                                            }else
                                            {
                                                output += "\nTenant "+arrHouse.get(iCounter).getTenant()[0].toString();
                                            }
                                            output += "\nLease details: \tNumber of weeks ("+arrHouse.get(iCounter).getLease().getNumWeeks()+") Rent Amount (R "+arrHouse.get(iCounter).getLease().getRent();
                                            

                                        }
                        
                                 System.out.println(output); 
                                 String details = setUserOptions("Enter -1 to go to the main menu.\nEnter -2 to exit the program.");
                                 switch (details)
                                 {
                                     case "-1" : menu();
                                     break;
                                     case "-2" : System.exit(0);
                                     break;         
                                 }
                            break;
                            case 5:
                                iCounter = 0;
                                String selection = setUserOptions("Enter -1 to go back to the main menu.\nEnter -2 to add another tenant.\nEnter -3 to remove a tenant.\nEnter -4 to replace a tenant.\nEnter -5 to exit the program.");

                                switch (selection)
                                {
                                    case "-1" : menu();
                                    break;
                                    case "-2" : 
                                        iCounter = leasedHouses();
                                        if (addTenants(iCounter))
                                        {System.out.println("\nTenant successfully added to House:"+arrHouse.get(iCounter).toString());}
                                        else
                                        {System.out.println("\nTenant could not be added. Maybe the max amount of tenants have been reached");}
                                        break;
                                    case "-3" : 
                                        int counter = 0;

                                        for (Person i : arrHouse.get(iCounter).getTenant())
                                        {
                                            System.out.println(counter+"."+i);
                                            counter++;
                                        }
                                        
                                    input = setUserOptions("\nEnter -1 to go back to the main menu.\nEnter -2 to exit the program.");  
                                    switch (input)
                                        {
                                            case "-1" : menu();
                                             break;
                                            case "-2" : System.exit(0);
                                             break;
                                            default :
                                                    if (Integer.parseInt(input) <= 2)
                                                    {
                                                        if(arrHouse.get(iCounter).removeTenant(Integer.parseInt(input)))
                                                        {
                                                            System.out.println("\nTenant successfully removed");
                                                        }else
                                                        {
                                                            System.out.println("\nSomething went wrong.");
                                                        }
                                                    }
                                        }

                                        break;
                                    case "-4" :
                                            counter = 0;
                                            for (Person i : arrHouse.get(iCounter).getTenant())
                                            {
                                                System.out.println(counter+"."+i);
                                                counter++;
                                            }boolean active = true;
                                        while (active)
                                        {
                                            input = setUserOptions("\nEnter -1 to go back to the main menu.\nEnter -2 to exit the program.");

                                            switch (input)
                                            {
                                                case "-1" :
                                                     active = false;
                                                     menu();
                                                    break;
                                                case "-2" :
                                                     active = false;
                                                     System.exit(0);
                                                    break;
                                                default :
                                                     System.out.println("Woops you entered something wrong. Let's retry.");
                                                    break;
                                            }
                                            
                                        }
                                        break;
                                    case "-5" : System.exit(0);
                                    break;


                                }

                                iCounter = leasedHouses();

                                addTenant:
                                {
                                if (addTenants(iCounter))
                                {System.out.println("\nTenant successfully added to House:"+arrHouse.get(iCounter).toString());}
                                else
                                {System.out.println("\nTenant could not be added. Maybe the max amount of tenants have been added");}
                                }

                                //String selection = setUserOptions("Enter -1 to go back to the main menu.\nEnter -2 to add another tenant.\nEnter -3 to replace a tenant in the current house.");

                                break;
                            case 6:
                                System.exit(0);
                                break;
                        }
                                break;
           case 2:
                input = setUserOptions("\nEnter -1 to go back to the main menu.\nEnter -2 to exit the program.");
                switch(input)
                {
                    case "-1" : menu();
                        break;
                    case "-2" : System.exit(0);
                        break;
                }
               break;
           case 3:
               input = setUserOptions("\n");
               break;
       }     
         
    }
    
}