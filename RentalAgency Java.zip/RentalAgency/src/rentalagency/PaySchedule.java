package rentalagency;

public class PaySchedule
{
    
    private int rent;
    private int numWeeks;
    
    public PaySchedule()
    {
        this.rent = 0;
        this.numWeeks = 0;
    }
    
    public PaySchedule(int rent, int numWeeks)
    {
        this.rent = rent;
        this.numWeeks = numWeeks;
    }
    
    public int getRent()
    {
        return this.rent;
    }
    
    public int getNumWeeks()
    {
        return this.numWeeks;
    }
    
    public boolean makePayment()
    {
        if (this.numWeeks == 0) {return false;}
        --this.numWeeks;
        return true;
    }
}