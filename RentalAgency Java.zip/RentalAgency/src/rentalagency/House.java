package rentalagency;

/*

    Constructor.
        *House
            -Accepts String, Town object, Person object.
    

    Method description.
   
        toString()
            -Returns String
            -Accepts nothing
         *Functionality:
            -Compiles the property code, address and town name into a single
             readable string.

        establishLease()
            -Returns void
            -Accepts (String, String, Int, Int)
         *Functionality:
            -Creates a tenant and adds the amount that the tenant needs to pay
             with the amount of weeks.

        payRent()
            -Returns boolean
            -Accepts nothing
         *Functionality:
            -Checks if there is a lease and if there is it calls the method 
                makePayment() in the Lease class.

        getTown()
            -Returns Town object.
            -Accepts nothing.

         *Functionality
            -Creates a new Town object from the existing one instantiated by 
              the constructor (gets rid of privacy leaks) and then returns
              the town object to the calling statement.

        getOwner()
            -Returns Person object
            -Accepts nothing
            
         *Functionality
            -Creates a new Person object from the existing one instantiated by
             the constructor (gets rid of privacy leaks) and then returns 
             the Person object to the calling statement.

        getPropCode()
            -Returns int
            -Accepts nothing
         *Functionality
            -Stores the property code into a temporary variable which is then
              returned to the calling statement.

        getAddress()
            -Returns String
            -Accepts nothing
         *Functionality
            -Stores the address into a temporary variable which is then returned
              to the calling statement.

        getTenant()
            -Returns Tenant object
            -Accepts nothing
         *Functionality
            -Creates a temporary tenant object and stores the current tenant
              instide it. (gets rid of privacy leaks). It then returns the 
              tenant object to the calling statement.
            

         getLease()
            -Returns PaySchedule object
            -Accepts nothing
         *Functionality
            -Creates a temporary PaySchedule object which then stores the
    
         addTenant(Person tenant)
            -returns boolean
            -Accepts type Person tenant.
          *Functionality
            -adds a tenant


         removeTenant(int index)
            -returns boolean
            -Accepts the index of the person you want to remove
          *Functionality
            -Removes a tenant (by specifying the array index)
*/



public class House
{
    
    public String address;
    private static int propCode = 0;
    private int pCode = 0;
    private final Town town;
    private final Person owner;
    private Person[] tenant = new Person[3];
    private PaySchedule lease;

    public House(String address, Town town, Person owner)
    {
        this.town = town;
        this.owner = owner;
        this.lease = new PaySchedule();
        this.tenant[0] = new Person();
        this.address = address;
        this.pCode = House.propCode;
        ++House.propCode;
        
    }
    
    @Override
    public String toString()
    {
        return "Property Code: "+getPropCode()+"\nAddress: "+getAddress()+" "+getTown().getName();
    }
    
    public void establishLease(String name, String number, int rentAmount, int numWeeks)
    {
        this.tenant = new Person[3];
        this.tenant[0] = new Person(name, number);
        this.lease = new PaySchedule(rentAmount, numWeeks);
    }
    
    public boolean payRent()
    {
        if (this.lease == null) {return false;}
        if (this.lease.makePayment()) {return true;}
        else {return false;}
    }
    
    public Town getTown()
    {
        Town temp = this.town;
        return temp;
    }
    
    public Person getOwner()
    {
        Person temp = this.owner;
        return temp;
    }
    
    public int getPropCode()
    {
        int temp = pCode;
        return temp;
    }
    
    public String getAddress()
    {
        String temp = this.address;
        return temp;
    }
    
    public Person[] getTenant()
    {
        Person[] temp = this.tenant;
        return temp;
    }
    
    public PaySchedule getLease()
    {
        PaySchedule temp = this.lease;
        return temp;
    }
    
    public boolean addTenant(Person tenant)
    {
        if (getLease() == null) {return false;}
        if (this.tenant[2] != null) {return false;}
        
        if (this.tenant[0] == null) {this.tenant[0] = tenant;}
        else if (this.tenant[1] == null){this.tenant[1] = tenant;}
        else {this.tenant[2] = tenant;}
        return true;
        
    }
    
    public boolean removeTenant(int index)
    {
        if (this.tenant[index].getName().equals(""))
            return false;
        this.tenant[index] = new Person();
        return true;
    }
}